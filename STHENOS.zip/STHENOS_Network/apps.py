from django.apps import AppConfig


class SthenosMotivationConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'STHENOS_Network'
