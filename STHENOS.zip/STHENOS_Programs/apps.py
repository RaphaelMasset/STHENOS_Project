from django.apps import AppConfig


class SthenosProgrammesConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'STHENOS_Programs'
